import { useState } from 'react';
import { Table, Badge } from 'react-bootstrap';
import { Coin } from '../types/Coin';
import { CoinDetailsModal } from './CoinDetailsModal';

interface CoinsTableProps {
  coins: Coin[];
  onSort: (key: keyof Coin) => void;
  sortConfig: { key: keyof Coin; direction: string } | null;
}

export const CoinsTable = ({ coins, onSort, sortConfig }: CoinsTableProps) => {
  const [selectedCoin, setSelectedCoin] = useState<Coin | null>(null);
  const [showModal, setShowModal] = useState(false);

  const handleRowClick = (coin: Coin) => {
    setSelectedCoin(coin);
    setShowModal(true);
  };

  const getSortDirectionIndicator = (key: keyof Coin) => {
    if (!sortConfig || sortConfig.key !== key) return null;
    return sortConfig.direction === 'ascending' ? ' ↑' : ' ↓';
  };

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('en-US', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(num);
  };

  return (
    <>
      <Table striped bordered hover responsive className="mt-4">
        <thead>
          <tr>
            <th onClick={() => onSort('market_cap_rank')}>
              Rank{getSortDirectionIndicator('market_cap_rank')}
            </th>
            <th>Name</th>
            <th onClick={() => onSort('current_price')}>
              Price{getSortDirectionIndicator('current_price')}
            </th>
            <th onClick={() => onSort('price_change_percentage_24h')}>
              24h %{getSortDirectionIndicator('price_change_percentage_24h')}
            </th>
            <th onClick={() => onSort('market_cap')}>
              Market Cap{getSortDirectionIndicator('market_cap')}
            </th>
            <th onClick={() => onSort('total_volume')}>
              Volume{getSortDirectionIndicator('total_volume')}
            </th>
          </tr>
        </thead>
        <tbody>
          {coins.map((coin) => (
            <tr
              key={coin.id}
              onClick={() => handleRowClick(coin)}
              style={{ cursor: 'pointer' }}
            >
              <td>{coin.market_cap_rank}</td>
              <td>
                <img
                  src={coin.image}
                  alt={coin.name}
                  width="24"
                  height="24"
                  className="me-2"
                />
                {coin.name} ({coin.symbol.toUpperCase()})
              </td>
              <td>${formatNumber(coin.current_price)}</td>
              <td>
                <Badge
                  bg={
                    coin.price_change_percentage_24h >= 0
                      ? 'success'
                      : 'danger'
                  }
                >
                  {coin.price_change_percentage_24h.toFixed(2)}%
                </Badge>
              </td>
              <td>${formatNumber(coin.market_cap)}</td>
              <td>${formatNumber(coin.total_volume)}</td>
            </tr>
          ))}
        </tbody>
      </Table>

      <CoinDetailsModal
        coin={selectedCoin}
        show={showModal}
        onHide={() => setShowModal(false)}
      />
    </>
  );
};
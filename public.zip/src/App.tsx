import { Container } from 'react-bootstrap';
import { useCoinGecko } from './hooks/useCoinGecko';
import { CoinsTable } from './components/CoinsTable';
import { HighlightsSection } from './components/HighlightsSection';
import { SearchAndSort } from './components/SearchAndSort';
import { Pagination } from './components/common/Pagination';
import { LoadingSpinner } from './components/common/LoadingSpinner';
import { ErrorMessage } from './components/common/ErrorMessage';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  const {
    coins,
    trendingCoins,
    loading,
    error,
    page,
    setPage,
    searchTerm,
    setSearchTerm,
    requestSort,
    sortConfig,
  } = useCoinGecko();

  const handleRetry = () => {
    window.location.reload();
  };

  return (
    <Container className="py-4">
      <h1 className="text-center mb-4">Crypto Dashboard</h1>
      
      {error && (
        <ErrorMessage message={error} onRetry={handleRetry} />
      )}

      {!error && (
        <>
          <HighlightsSection 
            trendingCoins={trendingCoins} 
            coins={coins} 
          />
          
          <SearchAndSort 
            searchTerm={searchTerm}
            onSearchChange={setSearchTerm}
          />

          {loading ? (
            <LoadingSpinner />
          ) : (
            <>
              <CoinsTable 
                coins={coins} 
                onSort={requestSort}
                sortConfig={sortConfig}
              />
              
              <Pagination
                currentPage={page}
                totalPages={10} // Assuming 10 pages for demo
                onPageChange={setPage}
              />
            </>
          )}
        </>
      )}
    </Container>
  );
}

export default App;
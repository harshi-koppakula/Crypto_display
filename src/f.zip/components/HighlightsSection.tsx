import { Row, Col, Table } from "react-bootstrap";

interface HighlightsSectionProps {
  trendingCoins: any[];
  coins: any[];
}

export const HighlightsSection = ({
  trendingCoins,
  coins,
}: HighlightsSectionProps) => {
  return (
    <Row className="mb-4 g-3">
      {/* === Left Stats === */}
      <Col md={4}>
        <div className="p-3 bg-white rounded-4 shadow-sm mb-3">
          <h6 className="text-muted">Market Cap</h6>
          <h4 className="text-success mb-1">$4,100,825,920,482</h4>
          <div className="small text-success fw-semibold">+1.2% (24h)</div>
          <div
            className="bg-light mt-2"
            style={{ height: 60, borderRadius: 6 }}
          />
        </div>

        <div className="p-3 bg-white rounded-4 shadow-sm">
          <h6 className="text-muted">24h Trading Volume</h6>
          <h4 className="text-success mb-1">$169,738,442,965</h4>
          <div className="small text-success fw-semibold">+0.8% (24h)</div>
          <div
            className="bg-light mt-2"
            style={{ height: 60, borderRadius: 6 }}
          />
        </div>
      </Col>

      {/* === Right Highlight Tables === */}
      <Col md={8}>
        <Row className="g-3">
          {/* Trending */}
          <Col md={4}>
            <div className="p-3 bg-white rounded-4 shadow-sm h-100">
              <h6 className="fw-semibold mb-2">Trending</h6>
              <Table size="sm" borderless responsive>
                <tbody>
                  {trendingCoins?.slice(0, 3).map((coin, idx) => (
                    <tr key={idx}>
                      <td className="fw-medium">{coin.item.name}</td>
                      <td className="text-success fw-semibold">
                        +{(Math.random() * 10).toFixed(2)}%
                      </td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </div>
          </Col>

          {/* Top Gainers */}
          <Col md={4}>
            <div className="p-3 bg-white rounded-4 shadow-sm h-100">
              <h6 className="fw-semibold mb-2">Top Gainers</h6>
              <Table size="sm" borderless responsive>
                <tbody>
                  {[...coins]
                    .sort(
                      (a, b) =>
                        b.price_change_percentage_24h -
                        a.price_change_percentage_24h
                    )
                    .slice(0, 3)
                    .map((coin) => (
                      <tr key={coin.id}>
                        <td className="fw-medium text-uppercase">
                          {coin.symbol}
                        </td>
                        <td className="text-success fw-semibold">
                          +{coin.price_change_percentage_24h.toFixed(2)}%
                        </td>
                      </tr>
                    ))}
                </tbody>
              </Table>
            </div>
          </Col>

          {/* Top Losers */}
          <Col md={4}>
            <div className="p-3 bg-white rounded-4 shadow-sm h-100">
              <h6 className="fw-semibold mb-2">Top Losers</h6>
              <Table size="sm" borderless responsive>
                <tbody>
                  {[...coins]
                    .sort(
                      (a, b) =>
                        a.price_change_percentage_24h -
                        b.price_change_percentage_24h
                    )
                    .slice(0, 3)
                    .map((coin) => (
                      <tr key={coin.id}>
                        <td className="fw-medium text-uppercase">
                          {coin.symbol}
                        </td>
                        <td className="text-danger fw-semibold">
                          {coin.price_change_percentage_24h.toFixed(2)}%
                        </td>
                      </tr>
                    ))}
                </tbody>
              </Table>
            </div>
          </Col>
        </Row>
      </Col>
    </Row>
  );
};

import { Card, Row, Col, Badge } from 'react-bootstrap';
import { TrendingCoin } from '../types/Coin';

interface HighlightsSectionProps {
  trendingCoins: TrendingCoin[];
  coins: any[];
}

export const HighlightsSection = ({
  trendingCoins,
  coins,
}: HighlightsSectionProps) => {
  // Get top gainers and losers
  const topGainers = [...coins]
    .sort((a, b) => b.price_change_percentage_24h - a.price_change_percentage_24h)
    .slice(0, 5);

  const topLosers = [...coins]
    .sort((a, b) => a.price_change_percentage_24h - b.price_change_percentage_24h)
    .slice(0, 5);

  const highestVolume = [...coins]
    .sort((a, b) => b.total_volume - a.total_volume)
    .slice(0, 5);

  const formatNumber = (num: number) => {
    if (num > 1000000000) {
      return (num / 1000000000).toFixed(2) + 'B';
    }
    if (num > 1000000) {
      return (num / 1000000).toFixed(2) + 'M';
    }
    if (num > 1000) {
      return (num / 1000).toFixed(2) + 'K';
    }
    return num.toFixed(2);
  };

  return (
    <Row className="my-4">
      <Col md={6} lg={3} className="mb-3">
        <Card>
          <Card.Header>
            <h6 className="mb-0">Top Gainers (24h)</h6>
          </Card.Header>
          <Card.Body>
            {topGainers.map((coin) => (
              <div key={coin.id} className="d-flex justify-content-between mb-2">
                <span>
                  {coin.symbol.toUpperCase()}
                </span>
                <Badge bg="success">
                  +{coin.price_change_percentage_24h.toFixed(2)}%
                </Badge>
              </div>
            ))}
          </Card.Body>
        </Card>
      </Col>

      <Col md={6} lg={3} className="mb-3">
        <Card>
          <Card.Header>
            <h6 className="mb-0">Top Losers (24h)</h6>
          </Card.Header>
          <Card.Body>
            {topLosers.map((coin) => (
              <div key={coin.id} className="d-flex justify-content-between mb-2">
                <span>
                  {coin.symbol.toUpperCase()}
                </span>
                <Badge bg="danger">
                  {coin.price_change_percentage_24h.toFixed(2)}%
                </Badge>
              </div>
            ))}
          </Card.Body>
        </Card>
      </Col>

      <Col md={6} lg={3} className="mb-3">
        <Card>
          <Card.Header>
            <h6 className="mb-0">Highest Volume</h6>
          </Card.Header>
          <Card.Body>
            {highestVolume.map((coin) => (
              <div key={coin.id} className="d-flex justify-content-between mb-2">
                <span>
                  {coin.symbol.toUpperCase()}
                </span>
                <span>${formatNumber(coin.total_volume)}</span>
              </div>
            ))}
          </Card.Body>
        </Card>
      </Col>

      <Col md={6} lg={3} className="mb-3">
        <Card>
          <Card.Header>
            <h6 className="mb-0">Trending Coins</h6>
          </Card.Header>
          <Card.Body>
            {trendingCoins.slice(0, 5).map((coin) => (
              <div key={coin.item.id} className="d-flex justify-content-between mb-2">
                <span>
                  {coin.item.symbol.toUpperCase()}
                </span>
                <small>{coin.item.name}</small>
              </div>
            ))}
          </Card.Body>
        </Card>
      </Col>
    </Row>
  );
};